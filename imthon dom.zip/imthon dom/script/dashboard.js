const $createForm = document.querySelector("form")
const $inputs = $createForm.querySelectorAll(".inputElement")




const handleCreateNewProduct = (e) => {
    e.preventDefault();

    const values = Array.from($inputs).map(input => input.value)
    let product = {
      title: values[0],
      image: values[1],
      tags: values[2],
      author: values[3],
      description: values[4]

    }

    fetch("https://blog-post-production-b61c.up.railway.app/api/v1/blogs", 
      {
          method: "POST",
          headers: {
            "Authorization": `Bearer ${ localStorage.getItem("token")}`,
              "Content-type" : "application/json"
          },
          body: JSON.stringify(product)
      }
  )
           .then(response => response.json())
          .then(data => {
            if (data.status === 'success') {
                alert("Post created successfully");
                location.reload();
                location.replace("http://127.0.0.1:5500/");
            }
          })
          
}

$createForm.addEventListener("submit" , handleCreateNewProduct)