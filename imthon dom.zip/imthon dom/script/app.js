const $result = document.querySelector("#result")

fetch("https://blog-post-production-b61c.up.railway.app/api/v1/blogs")
.then(response => response.json())
.then(data => renderProducts(data))


const renderProducts  = (data) => {
    data.data.forEach(product => {
        const $div = document.createElement("div");
        $div.className = "card";
        $div.innerHTML = `
         <img width="300px" src="${product.image}" />
             
        <a href="/pages/singlepage.html">View more</a>
        <h3>${product.title}</h3>
        <p>${product.description.slice(0, 70) + "..."}<p/>
        <strong>$${product.price}</strong>
        `
        $result.appendChild($div)
    })
}






$result.addEventListener("click", handleProductActions)